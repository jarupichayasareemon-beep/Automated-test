import { test, expect, Page, BrowserContext } from '@playwright/test';
import path from 'node:path';
import { loadTranslations, createTranslator, LOCALES } from '../utils/i18n';
import { login } from './helpers/auth';
import { switchLanguage, detectCurrentLanguage } from './helpers/language';
import { createSharedPage, closeSharedPage } from './helpers/recording';

const translations = loadTranslations(
  path.join(__dirname, '../data/buyer-profile-payment-container.csv')
);
const t = createTranslator(translations);
const headingTextByCode = Object.fromEntries(
  LOCALES.map((l) => [l.code, t('save_cards_title', l.code)])
);

// This file uses a *second* account (TEST_EMPTY_EMAIL / TEST_EMPTY_PASSWORD)
// that has zero saved cards, to cover the "You haven't saved any cards
// yet." empty state — the main TEST_EMAIL account always has cards on it,
// so it can never show this state. Logs in directly in beforeAll (once for
// the whole file) rather than via storageState.json/auth.setup.ts, since
// that shared file is for the main account and switching accounts mid-run
// would fight the other spec files' assumption that the main account stays
// logged in throughout.
//
// .serial + one shared page across every test — see the longer explanation
// in delete-dialog-i18n.spec.ts (language switching is itself stateful, so
// these tests must run in order against one continuously-updated page).
test.describe.serial('Saved Cards page — empty state translations', () => {
  let page: Page;
  let context: BrowserContext | null;
  let currentLabel: string | null = null;

  test.beforeAll(async ({ browser }) => {
    ({ page, context } = await createSharedPage(browser));
    await login(page, {
      email: process.env.TEST_EMPTY_EMAIL,
      password: process.env.TEST_EMPTY_PASSWORD,
      envVarNames: ['TEST_EMPTY_EMAIL', 'TEST_EMPTY_PASSWORD'],
    });
  });

  test.afterAll(async () => {
    await closeSharedPage(page, context, 'empty-cards-i18n');
  });

  test.beforeEach(async () => {
    await page.goto('/user/payment');
  });

  for (const { code, label } of LOCALES) {
    test(`empty Saved Cards state is translated for ${code} (${label})`, async () => {
      if (currentLabel === null) {
        currentLabel = await detectCurrentLanguage(page, LOCALES, headingTextByCode);
      }
      await switchLanguage(page, currentLabel, label, t('save_cards_title', code));
      currentLabel = label;

      await expect(page.getByText(t('empty_card_title', code), { exact: true })).toBeVisible();
      await expect(page.getByText(t('empty_card_description', code), { exact: true })).toBeVisible();
    });
  }
});
