import { test, expect, Page, BrowserContext } from '@playwright/test';
import path from 'node:path';
import { loadTranslations, createTranslator, LOCALES } from '../utils/i18n';
import { switchLanguage, detectCurrentLanguage } from './helpers/language';
import { createSharedPage, closeSharedPage } from './helpers/recording';

const translations = loadTranslations(
  path.join(__dirname, '../data/buyer-profile-payment-container.csv')
);
const t = createTranslator(translations);
const headingTextByCode = Object.fromEntries(
  LOCALES.map((l) => [l.code, t('save_cards_title', l.code)])
);

// .serial + a page shared across every test in this file (created once in
// beforeAll) rather than the default fresh page per test — see the longer
// explanation in delete-dialog-i18n.spec.ts. Short version: storageState.json
// (tests/auth.setup.ts) captures a point-in-time snapshot, so a fresh page
// per test would keep reloading that original captured language, silently
// undoing switchLanguage() from previous tests; sharing one page keeps the
// live in-page language state — and currentLabel's tracking of it — correct.
test.describe.serial('Saved Cards page — main text translations', () => {
  let page: Page;
  let context: BrowserContext | null;
  // The site persists the selected language per-account, so the real
  // starting language of a fresh run can be whatever a previous session
  // last left it as — not necessarily "English". Detected once, on the
  // first test, from the page itself; see detectCurrentLanguage().
  let currentLabel: string | null = null;

  test.beforeAll(async ({ browser }) => {
    ({ page, context } = await createSharedPage(browser, { storageState: 'storageState.json' }));
  });

  test.afterAll(async () => {
    await closeSharedPage(page, context, 'saved-cards-i18n');
  });

  test.beforeEach(async () => {
    await page.goto('/user/payment');
  });

  for (const { code, label } of LOCALES) {
    test(`Saved Cards page shows correct text for ${code} (${label})`, async () => {
      if (currentLabel === null) {
        currentLabel = await detectCurrentLanguage(page, LOCALES, headingTextByCode);
      }
      await switchLanguage(page, currentLabel, label, t('save_cards_title', code));
      currentLabel = label;

      // The title text also appears in the sidebar nav item of the same
      // name, so getByText({exact: true}) alone is ambiguous (strict-mode
      // violation) — scope to the page heading's stable id instead.
      await expect(page.locator('#header-text-payment')).toHaveText(t('save_cards_title', code));
      await expect(page.getByText(t('save_cards_information', code))).toBeVisible();

      // These badges only render if the logged-in test account currently has
      // a default and/or expired card respectively. If your test account's
      // data is different, remove whichever check doesn't apply.
      const defaultBadge = page.getByText(t('card_default', code), { exact: true });
      if (await defaultBadge.count()) {
        await expect(defaultBadge.first()).toBeVisible();
      }

      const expiredBadge = page.getByText(t('card_expired', code), { exact: true });
      if (await expiredBadge.count()) {
        await expect(expiredBadge.first()).toBeVisible();
      }
    });
  }
});
