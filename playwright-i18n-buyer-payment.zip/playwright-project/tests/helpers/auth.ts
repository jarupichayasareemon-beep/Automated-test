import { Page } from '@playwright/test';

/**
 * Logs in on the dev-env sign-in page before each test.
 *
 * Verified against the real login page at
 * https://dev.ticketmelon.com/authen/sign-in?redirect_url= (form fields
 * only — the actual sign-in was NOT submitted from here; entering
 * credentials into a live form isn't something this assistant does on your
 * behalf. The field/button selectors below were confirmed from the page's
 * rendered DOM):
 *   - email input:    id="input-input-username"
 *   - password input: id="input-input-password", type="password"
 *   - submit button:  type="submit", id="btn-submit-login"
 *     (the accessible name "Sign in" is ambiguous — the header nav also has
 *     a "Sign in" button, which getByRole('button', { name: 'Sign in' })
 *     matches too, causing a strict-mode violation; the id is unambiguous)
 *
 * ids are used instead of placeholder text ("Enter your email" etc.)
 * because the sign-in page's language isn't guaranteed to be English — it
 * follows whatever language the site last had selected (see the NOTE on
 * LOCALES in utils/i18n.ts), which observably carries over even to a fresh,
 * cookie-less browser context. A second-account login hit this directly:
 * the placeholder read "輸入您的電子郵件" instead of "Enter your email",
 * so getByPlaceholder('Enter your email') never matched anything and this
 * function hung until the beforeAll hook timed out.
 *
 * Credentials default to the TEST_EMAIL / TEST_PASSWORD env vars (see
 * .env.example) — fill in your own `.env`, do not hardcode them here or
 * commit them. Pass `credentials` to log in as a different account instead
 * (e.g. tests/auth-empty.setup.ts uses TEST_EMPTY_EMAIL / TEST_EMPTY_PASSWORD
 * to reach an account with zero saved cards, for the empty-state tests).
 */
export async function login(
  page: Page,
  credentials?: { email: string | undefined; password: string | undefined; envVarNames: [string, string] }
): Promise<void> {
  const email = credentials?.email ?? process.env.TEST_EMAIL;
  const password = credentials?.password ?? process.env.TEST_PASSWORD;
  const [emailVar, passwordVar] = credentials?.envVarNames ?? ['TEST_EMAIL', 'TEST_PASSWORD'];

  if (!email || !password) {
    throw new Error(
      `${emailVar} / ${passwordVar} are not set. Copy .env.example to .env and fill them in ` +
        '(or switch to storageState-based auth — see the comment at the top of README.md ' +
        '"Authentication" section).'
    );
  }

  await page.goto('/authen/sign-in?redirect_url=');
  await page.locator('#input-input-username').fill(email);
  await page.locator('#input-input-password').fill(password);
  await page.locator('#btn-submit-login').click();

  // redirect_url was left empty in the URL used to reach this page, so the
  // exact post-login destination wasn't observed. Wait for the sign-in page
  // to go away rather than for a specific URL; the tests navigate to
  // /user/payment explicitly right after login() returns anyway.
  //
  // waitUntil defaults to 'load', which on this site's post-login landing
  // page can take well over 15s (heavy ad/analytics scripts) even though
  // navigation away from /authen/sign-in already happened — causing this
  // wait to time out intermittently despite login having actually
  // succeeded. 'domcontentloaded' fires as soon as the new page's DOM is
  // ready, which is all this check needs.
  await page.waitForURL((url) => !url.pathname.includes('/authen/sign-in'), {
    timeout: 15_000,
    waitUntil: 'domcontentloaded',
  });

  // Every fresh session shows a cookie-consent banner (fixed to the bottom
  // of the viewport) until dismissed. Left alone, it can intercept clicks
  // on controls near the bottom of later pages (e.g. the saved-card row
  // menu button). Dismissing it here means callers of login() don't each
  // need to handle it. Accepting is a one-time action per browser context,
  // so this only ever fires once per test.
  const acceptCookiesButton = page.locator('#btn-cookie-policy-accept-button');
  if (await acceptCookiesButton.isVisible().catch(() => false)) {
    await acceptCookiesButton.click();
  }
}
