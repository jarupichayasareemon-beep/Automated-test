import { test, expect, Page, BrowserContext } from '@playwright/test';
import path from 'node:path';
import { loadTranslations, createTranslator, LOCALES } from '../utils/i18n';
import { switchLanguage, detectCurrentLanguage } from './helpers/language';
import { createSharedPage, closeSharedPage } from './helpers/recording';

const translations = loadTranslations(
  path.join(__dirname, '../data/buyer-profile-payment-container.csv')
);
const t = createTranslator(translations);
const headingTextByCode = Object.fromEntries(
  LOCALES.map((l) => [l.code, t('save_cards_title', l.code)])
);

// .serial + a page shared across every test in this file — see the longer
// explanation in delete-dialog-i18n.spec.ts (storageState.json is a
// point-in-time snapshot, and language switching is itself stateful, so
// these tests must run in order against one continuously-updated page).
test.describe.serial('Saved Cards page — set-as-default confirmation dialog translations', () => {
  let page: Page;
  let context: BrowserContext | null;
  let currentLabel: string | null = null;

  test.beforeAll(async ({ browser }) => {
    ({ page, context } = await createSharedPage(browser, { storageState: 'storageState.json' }));
  });

  test.afterAll(async () => {
    await closeSharedPage(page, context, 'set-default-dialog-i18n');
  });

  test.beforeEach(async () => {
    await page.goto('/user/payment');
  });

  for (const { code, label } of LOCALES) {
    test(`set-as-default confirmation dialog is translated for ${code} (${label})`, async () => {
      if (currentLabel === null) {
        currentLabel = await detectCurrentLanguage(page, LOCALES, headingTextByCode);
      }
      await switchLanguage(page, currentLabel, label, t('save_cards_title', code));
      currentLabel = label;

      // Opens the "⋮" menu on the second saved card row (index 1) — the
      // first row (index 0) is already the default card and its menu has
      // no "Set as default" entry. Both the row's more-button and the
      // menu item have stable ids (confirmed by inspecting the rendered
      // DOM), unlike the delete flow's original row-locator heuristic.
      await page.locator('#card-action-more-1').click();
      await page.locator('#action-set-default-card').click();

      const dialog = page.getByRole('dialog');
      await expect(dialog).toBeVisible();
      await expect(
        dialog.getByText(t('dialog_confirm_set_default_title', code), { exact: true })
      ).toBeVisible();
      await expect(
        dialog.getByText(t('dialog_confirm_set_default_description', code))
      ).toBeVisible();
      await expect(
        dialog.getByText(t('dialog_confirm_button', code), { exact: true })
      ).toBeVisible();

      // Cancel out — this test must NOT actually change the default card.
      await dialog
        .getByText(t('dialog_confirm_cancel_button', code), { exact: true })
        .click();
      await expect(dialog).not.toBeVisible();
    });
  }

  // TODO: not covered yet — confirming the set-as-default (not just
  // canceling) and asserting the post-confirm success toast's translation
  // (default_card_updated). Needs a plan for disposable test card data
  // first: confirming for real would change which of the account's 3 cards
  // is the default, and every other i18n test in this suite assumes the
  // current default/expired card arrangement.
});
