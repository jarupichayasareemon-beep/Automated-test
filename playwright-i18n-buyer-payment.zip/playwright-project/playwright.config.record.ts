import { defineConfig, devices } from '@playwright/test';
import 'dotenv/config';

// For generating a video per test (pass or fail) to attach as evidence in
// Jira — the main config only keeps video on failure (video: 'retain-on-
// failure') to avoid piling up artifacts on every normal run.
//
// Written as a standalone config (rather than merging playwright.config.ts
// via defineConfig(base, overrides)) because that merge did not reliably
// push a top-level `use.video` override down into the "chromium" project's
// own `use` block (which already sets storageState) — video stayed off for
// every actual test, only showing up for "setup" one run and disappearing
// entirely the next. Not worth chasing further; duplicating the handful of
// settings here is more predictable.
// slowMo makes every Playwright action (clicks, etc.) take longer, so
// popups that would otherwise open and close within a fraction of a
// second — too fast to make out watching live, and just as invisible as a
// few blurry frames in a normal-speed recording — actually show up on
// screen for a beat in the recorded video.
const SLOW_MO_MS = 800;

export default defineConfig({
  testDir: './tests',
  timeout: 60_000,
  fullyParallel: false,
  workers: 1,
  retries: process.env.CI ? 1 : 0,
  preserveOutput: 'always',
  reporter: [['json', { outputFile: 'recordings/results.json' }], ['list']],
  use: {
    baseURL: process.env.BASE_URL || 'https://dev.ticketmelon.com',
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
    video: 'on',
    launchOptions: { slowMo: SLOW_MO_MS },
  },
  projects: [
    { name: 'setup', testMatch: /auth\.setup\.ts/ },
    {
      name: 'chromium',
      use: {
        ...devices['Desktop Chrome'],
        storageState: 'storageState.json',
        video: 'on',
        launchOptions: { slowMo: SLOW_MO_MS },
      },
      dependencies: ['setup'],
    },
  ],
});
