import { Page } from '@playwright/test';

/**
 * Switches the site's UI language via the header language switcher, then
 * confirms it actually took effect.
 *
 * Verified manually on https://dev.ticketmelon.com/user/payment:
 *  - A button in the header shows the current language's display name
 *    (e.g. "English", "ไทย", "Melayu") next to a globe icon.
 *  - Clicking it opens a dropdown with role="menuitem" entries for all 9
 *    languages, always in the same order and always in each language's own
 *    native name (i.e. the labels themselves don't change when you switch
 *    language — "ไทย" is always labeled "ไทย" no matter what the current UI
 *    language is).
 *
 * Because of that, `currentLabel` must be tracked by the caller (it cannot
 * be read from CSV/locale code — it's the *display label*, not the key).
 *
 * `expectedHeadingText` is the page's "Saved Cards" heading
 * (`#header-text-payment`) translated into targetLabel's language — pass
 * `t('save_cards_title', targetCode)`. Earlier versions of this function
 * confirmed the switch by waiting for a header *button* to relabel itself
 * to targetLabel, which turned out to still produce false positives (the
 * click having no visible effect, yet something on the page satisfied the
 * button-name match) and downstream steps would proceed against a page
 * that silently hadn't switched. The heading's actual rendered text,
 * checked against our own translation data, is unambiguous ground truth.
 */
export async function switchLanguage(
  page: Page,
  currentLabel: string,
  targetLabel: string,
  expectedHeadingText: string,
  attempts = 3
): Promise<void> {
  if (currentLabel === targetLabel) return;

  for (let attempt = 0; attempt < attempts; attempt++) {
    await page.getByRole('button', { name: currentLabel, exact: true }).click();
    await page.getByRole('menuitem', { name: targetLabel, exact: true }).click();

    const confirmed = await page
      .locator('#header-text-payment')
      .filter({ hasText: expectedHeadingText })
      .waitFor({ state: 'visible', timeout: 8_000 })
      .then(() => true)
      .catch(() => false);
    if (confirmed) return;
  }

  throw new Error(
    `switchLanguage: failed to switch from "${currentLabel}" to "${targetLabel}" after ${attempts} attempts — ` +
      `#header-text-payment never showed "${expectedHeadingText}".`
  );
}

/**
 * Detects the header language switcher's current label by reading the
 * page's "Saved Cards" heading (`#header-text-payment`) and matching its
 * text against `headingTextByCode` (build with
 * `Object.fromEntries(LOCALES.map(l => [l.code, t('save_cards_title', l.code)]))`).
 *
 * The site persists the selected language per-account (server-side, not in
 * browser storage — see the NOTE on LOCALES in utils/i18n.ts), so a fresh
 * test run can land on whatever language a previous session last left the
 * account in. switchLanguage() needs to know the *real* current label (not
 * an assumed one like "English") or it clicks the wrong header button and
 * every subsequent translation lookup times out.
 *
 * Earlier versions tried to infer this from getByRole('button', { name })
 * matches and from document.documentElement.lang — both produced
 * occasional false positives (something on the page satisfied the match
 * even though the visibly rendered language was different), leaving later
 * steps searching for one language's text on a page actually showing
 * another. The heading's own rendered text, checked against our own
 * translation CSV data, is unambiguous: it's the exact same ground truth
 * every assertion elsewhere in these tests already relies on.
 */
export async function detectCurrentLanguage(
  page: Page,
  locales: { code: string; label: string }[],
  headingTextByCode: Record<string, string>
): Promise<string> {
  const currentHeading = (await page.locator('#header-text-payment').textContent())?.trim() ?? '';
  const code = Object.entries(headingTextByCode).find(([, text]) => text === currentHeading)?.[0];
  const match = locales.find((l) => l.code === code);
  if (!match) {
    throw new Error(
      `Could not detect current UI language: #header-text-payment text "${currentHeading}" did not match any ` +
        `known translation.`
    );
  }
  return match.label;
}
