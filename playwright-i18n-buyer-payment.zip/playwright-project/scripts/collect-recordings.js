// Copies each test's video attachment (produced by playwright.config.record.ts,
// which forces video: 'on') out of the JSON reporter's raw paths and into
// recordings/ under a readable, per-test filename — ready to attach to Jira
// individually instead of hunting through content-hashed report data files.
const fs = require('fs');
const path = require('path');

const recordingsDir = path.join(__dirname, '..', 'recordings');
const resultsPath = path.join(recordingsDir, 'results.json');
const data = JSON.parse(fs.readFileSync(resultsPath, 'utf-8'));

function sanitize(name) {
  return name
    .replace(/[^a-z0-9]+/gi, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 150);
}

let count = 0;

function walkSuite(suite, titlePath) {
  const nextPath = suite.title ? [...titlePath, suite.title] : titlePath;
  for (const spec of suite.specs || []) {
    for (const test of spec.tests || []) {
      for (const result of test.results || []) {
        for (const attachment of result.attachments || []) {
          if (attachment.name !== 'video' || !attachment.path) continue;
          const fileName = `${sanitize([...nextPath, spec.title].join('-'))}.webm`;
          fs.copyFileSync(attachment.path, path.join(recordingsDir, fileName));
          count++;
        }
      }
    }
  }
  for (const child of suite.suites || []) {
    walkSuite(child, nextPath);
  }
}

for (const suite of data.suites || []) {
  walkSuite(suite, []);
}

console.log(`Saved ${count} recording(s) to ${recordingsDir}`);
