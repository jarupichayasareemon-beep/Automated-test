import { defineConfig } from '@playwright/test';
import baseConfig from './playwright.config';

// For visually watching the suite run: every Playwright action gets slowed
// down so popups/dialogs are actually visible instead of flashing open and
// closed within a fraction of a second. Kept as a separate config (rather
// than added to playwright.config.ts) so normal runs stay at full speed —
// use it with --headed:
//
//   npx playwright test --headed --config=playwright.config.watch.ts
//
export default defineConfig(baseConfig, {
  timeout: 60_000,
  use: {
    launchOptions: { slowMo: 800 },
  },
});
