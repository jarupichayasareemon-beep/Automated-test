import { Browser, BrowserContext, Page } from '@playwright/test';
import fs from 'node:fs';
import path from 'node:path';

const RECORDINGS_DIR = path.join(__dirname, '../../recordings');

/**
 * Creates the shared page each spec file uses across all of its locale
 * sub-tests (see the .describe.serial comment in delete-dialog-i18n.spec.ts
 * for why it's one page per file rather than the default page-per-test).
 *
 * That page is created via browser.newPage()/newContext() directly, which
 * bypasses the `page` fixture — and Playwright's automatic video recording
 * (the `video` option in playwright.config.ts) only wraps contexts created
 * through that fixture. A manually-created context needs `recordVideo`
 * passed at *creation* time instead (video recording can't be turned on
 * after the fact), which is what this does when RECORD_VIDEO is set (see
 * playwright.config.record.ts / `npm run test:record`) — otherwise it's a
 * plain page/no video, same as before, so normal runs aren't affected.
 */
export async function createSharedPage(
  browser: Browser,
  options: { storageState?: string } = {}
): Promise<{ page: Page; context: BrowserContext | null }> {
  if (!process.env.RECORD_VIDEO) {
    const page = await browser.newPage(options);
    return { page, context: null };
  }

  fs.mkdirSync(RECORDINGS_DIR, { recursive: true });
  const context = await browser.newContext({
    ...options,
    recordVideo: { dir: RECORDINGS_DIR },
  });
  const page = await context.newPage();
  return { page, context };
}

/**
 * Counterpart to createSharedPage() — closes the page/context and, if a
 * video was being recorded, renames Playwright's auto-generated filename
 * (a random id) to something readable and moves it into recordings/.
 */
export async function closeSharedPage(page: Page, context: BrowserContext | null, name: string): Promise<void> {
  if (!context) {
    await page.close();
    return;
  }

  const video = page.video();
  await context.close(); // finalizes the video file on disk
  if (!video) return;

  const originalPath = await video.path();
  const dest = path.join(RECORDINGS_DIR, `${name}.webm`);
  fs.renameSync(originalPath, dest);
}
