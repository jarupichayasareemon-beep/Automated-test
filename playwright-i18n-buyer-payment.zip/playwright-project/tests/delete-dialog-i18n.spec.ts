import { test, expect, Page, BrowserContext } from '@playwright/test';
import path from 'node:path';
import { loadTranslations, createTranslator, LOCALES } from '../utils/i18n';
import { switchLanguage, detectCurrentLanguage } from './helpers/language';
import { createSharedPage, closeSharedPage } from './helpers/recording';

const translations = loadTranslations(
  path.join(__dirname, '../data/buyer-profile-payment-container.csv')
);
const t = createTranslator(translations);
const headingTextByCode = Object.fromEntries(
  LOCALES.map((l) => [l.code, t('save_cards_title', l.code)])
);

// .serial + a page shared across every test in this file (created once in
// beforeAll) rather than the default fresh page per test. Two things in
// this file depend on that continuity:
//  - Authenticated session comes from storageState.json (see
//    tests/auth.setup.ts / playwright.config.ts), so no per-test login is
//    needed — but that alone doesn't mean these tests could safely each
//    get their own fresh page: storageState is a point-in-time snapshot,
//    so a fresh page would always reload the *original* captured language,
//    silently undoing whatever switchLanguage() did in previous tests.
//  - Language switching is itself stateful (each switch happens relative
//    to whichever language is "currently selected" in the live page), so
//    the tests must run in order against that one continuously-updated
//    page, not in parallel or against independent pages.
test.describe.serial('Saved Cards page — delete confirmation dialog translations', () => {
  let page: Page;
  let context: BrowserContext | null;
  // The site persists the selected language per-account, so the real
  // starting language of a fresh run can be whatever a previous session
  // last left it as — not necessarily "English". Detected once, on the
  // first test, from the page itself; see detectCurrentLanguage().
  let currentLabel: string | null = null;

  test.beforeAll(async ({ browser }) => {
    ({ page, context } = await createSharedPage(browser, { storageState: 'storageState.json' }));
  });

  test.afterAll(async () => {
    await closeSharedPage(page, context, 'delete-dialog-i18n');
  });

  test.beforeEach(async () => {
    await page.goto('/user/payment');
  });

  for (const { code, label } of LOCALES) {
    test(`delete confirmation dialog is translated for ${code} (${label})`, async () => {
      if (currentLabel === null) {
        currentLabel = await detectCurrentLanguage(page, LOCALES, headingTextByCode);
      }
      await switchLanguage(page, currentLabel, label, t('save_cards_title', code));
      currentLabel = label;

      // Opens the "⋮" menu on the first saved card row. The button has a
      // stable id ("card-action-more-0" for the first row, incrementing per
      // row) — confirmed by inspecting the row's rendered DOM, which is far
      // more reliable than deriving it from card-number text via an
      // ancestor heuristic (the nearest ancestor div/li to the card-number
      // text turned out to be a tight wrapper with no button inside it at
      // all, causing this click to time out).
      await page.locator('#card-action-more-0').click();

      await page.getByText(t('card_delete', code), { exact: true }).click();

      const dialog = page.getByRole('dialog');
      await expect(dialog).toBeVisible();
      await expect(
        dialog.getByText(t('dialog_confirm_delete_title', code), { exact: true })
      ).toBeVisible();
      await expect(
        dialog.getByText(t('dialog_confirm_delete_description', code))
      ).toBeVisible();
      await expect(
        dialog.getByText(t('dialog_confirm_delete_button', code), { exact: true })
      ).toBeVisible();

      // Cancel out — this test must NOT actually delete the card.
      await dialog
        .getByText(t('dialog_confirm_cancel_button', code), { exact: true })
        .click();
      await expect(dialog).not.toBeVisible();
    });
  }

  // TODO: not covered yet — confirming the delete (not just canceling) and
  // asserting the post-delete success message's translation, for each of
  // the 3 flows in the "Delete Default Card Flow" design (only-default-card
  // left / multiple cards / expired card). Needs a plan for disposable test
  // card data first, since actually deleting is destructive and the current
  // test account's 3 saved cards map 1:1 to those flows — deleting them for
  // real would leave nothing to re-run the test against next time.
});
