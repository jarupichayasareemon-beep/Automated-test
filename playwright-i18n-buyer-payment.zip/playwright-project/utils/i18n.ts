import fs from 'node:fs';
import { parse } from 'csv-parse/sync';

export type LocaleCode =
  | 'en-US'
  | 'th'
  | 'vi'
  | 'zh-CN'
  | 'id'
  | 'ms-MY'
  | 'ko-KR'
  | 'ja-JP'
  | 'zh-HK';

/**
 * Display label shown inside the site's language switcher dropdown
 * (top-right header, globe icon). Order matches the order the items
 * appear in the dropdown menu — verified by manually clicking through
 * the dropdown on https://dev.ticketmelon.com/user/payment.
 *
 * NOTE: navigating directly to a locale-prefixed URL
 * (e.g. https://dev.ticketmelon.com/ms-MY/user/payment) is NOT reliable —
 * during manual testing the app redirected back to whatever language was
 * last selected through the UI (the preference appears to be stored
 * per-account or in a cookie, independent of the URL you request). Always
 * switch language by clicking through the dropdown (see switchLanguage in
 * the test files), not by constructing URLs.
 */
export const LOCALES: { code: LocaleCode; label: string }[] = [
  { code: 'en-US', label: 'English' },
  { code: 'th', label: 'ไทย' },
  { code: 'zh-CN', label: '中文' },
  { code: 'ms-MY', label: 'Melayu' },
  { code: 'vi', label: 'Tiếng Việt' },
  { code: 'id', label: 'Indonesia' },
  { code: 'ko-KR', label: '한국어' },
  { code: 'ja-JP', label: '日本語' },
  { code: 'zh-HK', label: '繁體中文' },
];

export type TranslationRow = Record<LocaleCode, string> & { key: string };

/**
 * Parses the "Key-FE,en-US,th,vi,zh-CN,id,ms-MY,ko-KR,ja-JP,zh-HK" CSV export
 * into an array of rows keyed by locale code.
 */
export function loadTranslations(csvPath: string): TranslationRow[] {
  const raw = fs.readFileSync(csvPath, 'utf-8');
  const records: string[][] = parse(raw, {
    relax_column_count: true,
    skip_empty_lines: true,
  });

  const header = records[0];
  const rows = records.slice(1);

  return rows
    .filter((r) => r.some((cell) => cell && cell.trim() !== ''))
    .map((r) => {
      const row: Record<string, string> = {};
      header.forEach((col, idx) => {
        const value = r[idx] ?? '';
        row[idx === 0 ? 'key' : col] = value;
      });
      return row as TranslationRow;
    });
}

export function findByKey(rows: TranslationRow[], key: string): TranslationRow | undefined {
  return rows.find((r) => r.key === key);
}

/**
 * Builds a `t(key, locale)` helper bound to a loaded translation table.
 * Throws early (at test setup, not deep inside an assertion) if a key is
 * missing from the CSV or a locale column is empty for that key — this
 * catches CSV typos immediately instead of producing a confusing Playwright
 * "element not visible" failure.
 */
export function createTranslator(rows: TranslationRow[]) {
  return function t(key: string, locale: LocaleCode): string {
    const row = findByKey(rows, key);
    if (!row) throw new Error(`Missing translation key in CSV: "${key}"`);
    const value = row[locale];
    if (!value) throw new Error(`Missing "${locale}" value for key "${key}" in CSV`);
    return value;
  };
}
